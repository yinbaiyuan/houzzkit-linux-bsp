This directory contains a copy of the
[glad2](https://github.com/Dav1dde/glad/tree/glad2) library.

The contents of this directory can be recreated (at the latest available
upstream version) with [this][permalink] permalink.

[permalink]: https://gen.glad.sh/#generator=c&api=egl%3D1.5%2Cgl%3D2.1%2Cgles2%3D2.0%2Cglx%3D1.4%2Cwgl%3D1.0&profile=gl%3Dcompatibility%2Cgles1%3Dcommon&extensions=EGL_EXT_platform_base%2CEGL_KHR_platform_gbm%2CEGL_KHR_platform_wayland%2CEGL_KHR_platform_x11%2CGLX_EXT_swap_control%2CGLX_MESA_swap_control%2CGL_EXT_framebuffer_object%2CGL_OES_mapbuffer%2CGL_OES_required_internalformat%2CWGL_ARB_extensions_string%2CWGL_EXT_extensions_string%2CWGL_EXT_swap_control
